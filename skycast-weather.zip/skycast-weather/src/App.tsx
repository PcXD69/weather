import { useCallback, useEffect, useMemo, useState } from 'react';
import type { Place, Settings } from './types';
import { DEFAULT_SETTINGS, SettingsContext } from './context/SettingsContext';
import { useToast } from './context/Toast';
import { useLocalStorage } from './hooks/useMisc';
import { useTheme } from './hooks/useTheme';
import { useWeather } from './hooks/useWeather';
import { nameCoordinates } from './lib/api';
import { describe } from './lib/weather';
import { Atmosphere } from './components/Atmosphere';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Hourly } from './components/Hourly';
import { Daily } from './components/Daily';
import { Metrics } from './components/Metrics';
import { SearchModal } from './components/SearchModal';
import { SettingsModal } from './components/SettingsModal';
import { ErrorState, Skeletons, Welcome } from './components/States';

export default function App() {
  const toast = useToast();
  const { theme, toggle, setTheme } = useTheme();
  const [settings, setSettings] = useLocalStorage<Settings>('wx.settings', DEFAULT_SETTINGS);
  const [place, setPlace] = useLocalStorage<Place | null>('wx.place', null);
  const [favs, setFavs] = useLocalStorage<Place[]>('wx.favs', []);
  const [recent, setRecent] = useLocalStorage<Place[]>('wx.recent', []);
  const [searchOpen, setSearchOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [locating, setLocating] = useState(false);
  const { data, loading, error, stale, refresh } = useWeather(place, settings.refresh);

  const cond = useMemo(() => describe(data?.current.code ?? 0), [data?.current.code]);

  // "Follow local daylight": match the theme to the selected city (not saved as a manual choice).
  useEffect(() => {
    if (settings.autoTheme && data) setTheme(data.current.isDay ? 'light' : 'dark', false);
  }, [settings.autoTheme, data?.current.isDay, data?.tz, setTheme]); // eslint-disable-line react-hooks/exhaustive-deps

  // Keep an eye on API problems while stale data is on screen.
  useEffect(() => { if (error && data) toast(error, 'error'); }, [error]); // eslint-disable-line react-hooks/exhaustive-deps

  const pick = useCallback((p: Place) => {
    setPlace(p);
    setRecent(r => [p, ...r.filter(x => x.id !== p.id)].slice(0, 8));
    setSearchOpen(false); setSettingsOpen(false);
  }, [setPlace, setRecent]);

  const isFav = !!place && favs.some(f => f.id === place.id);
  const toggleFav = useCallback((p: Place) => {
    const has = favs.some(x => x.id === p.id);
    setFavs(has ? favs.filter(x => x.id !== p.id) : [...favs, p]);
    toast(has ? `${p.name} removed from favorites` : `${p.name} added to favorites`, has ? 'info' : 'success');
  }, [favs, setFavs, toast]);

  const locate = useCallback(() => {
    if (!('geolocation' in navigator)) { toast('Your browser does not support location access.', 'error'); return; }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      async pos => {
        const p = await nameCoordinates(pos.coords.latitude, pos.coords.longitude);
        setLocating(false); pick(p);
      },
      err => {
        setLocating(false);
        toast(err.code === err.PERMISSION_DENIED ? 'Location permission was denied. You can still search for a city.' : 'We could not determine your location.', 'error');
      },
      { enableHighAccuracy: false, timeout: 12000, maximumAge: 600000 });
  }, [pick, toast]);

  const reset = () => {
    Object.keys(localStorage).filter(k => k.startsWith('wx.')).forEach(k => localStorage.removeItem(k));
    window.location.reload();
  };

  const body = !place ? <Welcome onSearch={() => setSearchOpen(true)} onLocate={locate} locating={locating} />
    : !data ? (error ? <ErrorState message={error} onRetry={refresh} /> : <Skeletons />)
    : (
      <div key={place.id}>
        <Hero place={place} data={data} fav={isFav} onFav={() => toggleFav(place)} onRefresh={refresh} busy={loading || stale} stale={stale} />
        <Hourly data={data} />
        <div className="cols">
          <Daily data={data} />
          <Metrics data={data} />
        </div>
      </div>
    );

  return (
    <SettingsContext.Provider value={settings}>
      <Atmosphere cond={cond} wind={data?.current.windSpeed ?? 0} windDir={data?.current.windDir ?? 270} dark={theme === 'dark'} low={settings.effects === 'low'} />
      <div className="page">
        <Header place={place} settings={settings} onSettings={setSettings} theme={theme} onTheme={toggle} onSearch={() => setSearchOpen(true)} onOpenSettings={() => setSettingsOpen(true)} />
        <main id="main">{body}</main>
        <footer className="foot">Weather data by <a href="https://open-meteo.com/" target="_blank" rel="noreferrer">Open-Meteo.com</a></footer>
      </div>
      <SearchModal open={searchOpen} onClose={() => setSearchOpen(false)} onPick={pick} onLocate={locate} locating={locating}
        favs={favs} recent={recent} onToggleFav={toggleFav} onClearRecent={() => setRecent([])} />
      <SettingsModal open={settingsOpen} onClose={() => setSettingsOpen(false)} settings={settings} onChange={setSettings}
        favs={favs} onRemoveFav={p => setFavs(f => f.filter(x => x.id !== p.id))} onPick={pick} onReset={reset} />
    </SettingsContext.Provider>
  );
}
