import { useEffect, useMemo, useState } from 'react';
import type { Cond } from '../types';
import { useReducedMotion } from '../hooks/useMisc';
import { Particles } from './Particles';

const rng = (seed: number) => () => { seed |= 0; seed = (seed + 0x6d2b79f5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };

function Lightning({ on }: { on: boolean }) {
  const [bolt, setBolt] = useState<{ x: number; k: number } | null>(null);
  useEffect(() => {
    if (!on) return;
    let t = 0;
    const fire = () => { setBolt({ x: 8 + Math.random() * 80, k: Date.now() }); t = window.setTimeout(fire, 4500 + Math.random() * 7000); };
    t = window.setTimeout(fire, 1800);
    return () => window.clearTimeout(t);
  }, [on]);
  if (!on || !bolt) return null;
  return (
    <div key={bolt.k} className="lightning">
      <div className="flash" />
      <svg className="bolt" style={{ left: `${bolt.x}%` }} viewBox="0 0 120 140"><path d="M66 0 40 64h20L32 140l56-88H66L86 0z" /></svg>
    </div>
  );
}

export function Atmosphere({ cond, wind, windDir, dark, low }: { cond: Cond; wind: number; windDir: number; dark: boolean; low: boolean }) {
  const reduced = useReducedMotion();
  const stars = useMemo(() => {
    const r = rng(7);
    return Array.from({ length: 72 }, () => ({ x: r() * 100, y: r() * 62, s: 1 + r() * 2, d: r() * 6, t: 3 + r() * 5 }));
  }, []);
  const clouds = useMemo(() => {
    const r = rng(cond.clouds * 13 + 5);
    return Array.from({ length: cond.clouds }, (_, i) => {
      const sc = 0.55 + r() * 0.95, dur = 120 - sc * 45 + r() * 30;
      return { top: 3 + r() * 46, sc, dur, delay: -r() * dur, op: 0.5 + sc * 0.35, k: i };
    });
  }, [cond.clouds]);
  const clear = cond.sky === 'clear' || cond.sky === 'partly';

  return (
    <div className="atmo" data-sky={cond.sky} data-tone={cond.tone} data-fx={low ? 'low' : 'full'} aria-hidden="true">
      <svg width="0" height="0" className="defs">
        <defs>
          <linearGradient id="cg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" /><stop offset="1" /></linearGradient>
          <symbol id="cloud" viewBox="0 0 200 90">
            <g fill="url(#cg)"><circle cx="52" cy="56" r="24" /><circle cx="90" cy="38" r="33" /><circle cx="130" cy="46" r="28" /><circle cx="160" cy="58" r="20" /><rect x="40" y="56" width="132" height="22" rx="11" /></g>
          </symbol>
        </defs>
      </svg>
      <div className="sky sky-night" />
      <div className="sky sky-day" />
      <div className="tint" />
      <div className="stars">{stars.map((s, i) => <i key={i} style={{ left: `${s.x}%`, top: `${s.y}%`, width: s.s, height: s.s, animationDelay: `${s.d}s`, animationDuration: `${s.t}s` }} />)}</div>
      <div className="sun"><i className="glow" /><i className="rays" /><i className="core" /></div>
      <div className="moon"><i className="glow" /><i className="disc" /></div>
      <div className="clouds">
        {clouds.map(c => (
          <svg key={c.k} className="cloud" viewBox="0 0 200 90" style={{ top: `${c.top}%`, width: `${c.sc * 380}px`, opacity: c.op, animationDuration: `${c.dur}s`, animationDelay: `${c.delay}s`, zIndex: Math.round(c.sc * 10) }}>
            <use href="#cloud" />
          </svg>
        ))}
      </div>
      {cond.sky === 'fog' && <div className="fogs"><i /><i /><i /></div>}
      <Particles kind={cond.precip} power={cond.power} wind={wind} windDir={windDir} dark={dark} motes={clear} low={low} reduced={reduced} />
      <Lightning on={cond.sky === 'storm' && !reduced} />
      {cond.precip === 'rain' && <div className="gloss" />}
    </div>
  );
}
