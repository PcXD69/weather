import { MapPin, Search, Settings as Cog } from 'lucide-react';
import type { Place, Settings } from '../types';
import type { Theme } from '../hooks/useTheme';
import { IconButton, Segmented } from './ui';
import { ThemeToggle } from './ThemeToggle';

export function Header({ place, settings, onSettings, theme, onTheme, onSearch, onOpenSettings }: {
  place: Place | null; settings: Settings; onSettings: (s: Settings) => void; theme: Theme; onTheme: () => void; onSearch: () => void; onOpenSettings: () => void;
}) {
  const region = place ? [place.admin1, place.country].filter(Boolean).join(', ') : 'Search any city worldwide';
  return (
    <header className="hdr glass">
      <button type="button" className="loc" onClick={onSearch} aria-label="Change location">
        <span className="loc-pin"><MapPin size={18} strokeWidth={1.8} /></span>
        <span className="loc-text"><b>{place?.name ?? 'Choose a city'}</b><small>{region}</small></span>
      </button>
      <div className="hdr-actions">
        <IconButton label="Search cities" onClick={onSearch}><Search size={18} strokeWidth={1.8} /></IconButton>
        <div className="hide-sm">
          <Segmented label="Temperature unit" value={settings.temp} onChange={v => onSettings({ ...settings, temp: v })} options={[{ value: 'c', label: '°C' }, { value: 'f', label: '°F' }]} />
        </div>
        <ThemeToggle theme={theme} onToggle={onTheme} />
        <IconButton label="Settings" onClick={onOpenSettings}><Cog size={18} strokeWidth={1.8} /></IconButton>
      </div>
    </header>
  );
}
