import { cssVars } from '../lib/css';
import { useState } from 'react';
import { Clock, Droplets } from 'lucide-react';
import type { Weather } from '../types';
import { describe } from '../lib/weather';
import { hourLabel, temp } from '../lib/format';
import { useSettings } from '../context/SettingsContext';
import { WeatherIcon } from './WeatherIcon';

export function Hourly({ data }: { data: Weather }) {
  const s = useSettings();
  const [sel, setSel] = useState(0);
  return (
    <section className="card glass rise" style={cssVars({ '--i': 1 })} aria-labelledby="hourly-h">
      <h2 className="card-h" id="hourly-h"><Clock size={16} strokeWidth={1.8} /> Hourly forecast</h2>
      <div className="hscroll" role="list">
        {data.hourly.map((h, i) => {
          const cond = describe(h.code);
          return (
            <button key={h.time} role="listitem" type="button" className={`hour ${i === 0 ? 'now' : ''} ${sel === i ? 'sel' : ''}`} aria-pressed={sel === i} onClick={() => setSel(i)}
              aria-label={`${i === 0 ? 'Now' : hourLabel(h.time, s.h24)}, ${cond.label}, ${temp(h.temp, s.temp)} degrees`}>
              <span className="hour-t">{i === 0 ? 'Now' : hourLabel(h.time, s.h24)}</span>
              <WeatherIcon icon={cond.icon} isDay={h.isDay} size={26} />
              <b>{temp(h.temp, s.temp)}°</b>
              <span className="pop"><Droplets size={12} strokeWidth={1.8} />{h.pop ?? '–'}{h.pop !== null && '%'}</span>
            </button>
          );
        })}
      </div>
    </section>
  );
}
