import { useEffect, useMemo, useRef, useState, type KeyboardEvent as KbEvent } from 'react';
import { Heart, History, LocateFixed, Search, Star } from 'lucide-react';
import type { Place } from '../types';
import { searchPlaces } from '../lib/api';
import { Modal } from './Modal';

interface Props {
  open: boolean; onClose: () => void; onPick: (p: Place) => void; onLocate: () => void; locating: boolean;
  favs: Place[]; recent: Place[]; onToggleFav: (p: Place) => void; onClearRecent: () => void;
}

function Row({ p, active, fav, onPick, onFav }: { p: Place; active: boolean; fav: boolean; onPick: () => void; onFav: () => void }) {
  const sub = [p.admin1, p.country].filter(Boolean).join(', ');
  return (
    <li className={`srow ${active ? 'active' : ''}`} role="option" aria-selected={active}>
      <button type="button" className="srow-main" onClick={onPick}>
        <span className="cc">{p.cc ?? '··'}</span>
        <span className="srow-t"><b>{p.name}</b><small>{sub || 'Unknown region'} · {p.lat.toFixed(2)}°, {p.lon.toFixed(2)}°</small></span>
      </button>
      <button type="button" className={`iconbtn heart ${fav ? 'is-fav' : ''}`} aria-label={fav ? `Remove ${p.name} from favorites` : `Add ${p.name} to favorites`} onClick={onFav}>
        <Heart size={16} strokeWidth={1.8} fill={fav ? 'currentColor' : 'none'} />
      </button>
    </li>
  );
}

export function SearchModal({ open, onClose, onPick, onLocate, locating, favs, recent, onToggleFav, onClearRecent }: Props) {
  const [q, setQ] = useState('');
  const [results, setResults] = useState<Place[]>([]);
  const [state, setState] = useState<'idle' | 'loading' | 'error'>('idle');
  const [idx, setIdx] = useState(0);
  const input = useRef<HTMLInputElement>(null);
  const searching = q.trim().length >= 2;

  useEffect(() => { if (open) { setQ(''); setResults([]); setIdx(0); setState('idle'); } }, [open]);

  useEffect(() => {
    if (!open || !searching) { setResults([]); setState('idle'); return; }
    const c = new AbortController();
    setState('loading');
    const t = window.setTimeout(async () => {
      try { setResults(await searchPlaces(q, c.signal)); setState('idle'); setIdx(0); }
      catch (e: any) { if (e?.name !== 'AbortError') setState('error'); }
    }, 250);
    return () => { window.clearTimeout(t); c.abort(); };
  }, [q, open, searching]);

  const recentOnly = useMemo(() => recent.filter(r => !favs.some(f => f.id === r.id)), [recent, favs]);
  const flat = searching ? results : [...favs, ...recentOnly];
  const isFav = (p: Place) => favs.some(f => f.id === p.id);

  const key = (e: KbEvent) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setIdx(i => Math.min(flat.length - 1, i + 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setIdx(i => Math.max(0, i - 1)); }
    else if (e.key === 'Enter' && flat[idx]) { e.preventDefault(); onPick(flat[idx]); }
  };

  const list = (items: Place[], offset: number) => items.map((p, i) => (
    <Row key={p.id} p={p} active={offset + i === idx} fav={isFav(p)} onPick={() => onPick(p)} onFav={() => onToggleFav(p)} />
  ));

  return (
    <Modal open={open} onClose={onClose} title="Search location">
      <div className="search-box">
        <Search size={18} strokeWidth={1.8} />
        <input ref={input} data-autofocus value={q} onChange={e => setQ(e.target.value)} onKeyDown={key} placeholder="Search for a city…" aria-label="Search for a city"
          role="combobox" aria-expanded={flat.length > 0} aria-controls="search-list" autoComplete="off" spellCheck={false} />
      </div>
      <button type="button" className="btn locate" onClick={onLocate} disabled={locating}><LocateFixed size={18} strokeWidth={1.8} /> {locating ? 'Finding your location…' : 'Use my current location'}</button>
      <div className="search-body">
        {state === 'loading' && !results.length && <div className="skel" style={{ height: 56, marginBottom: 8 }} />}
        {state === 'error' && <p className="muted">Search is unavailable right now. Check your connection and try again.</p>}
        {searching && state === 'idle' && !results.length && <p className="muted">No cities found for “{q.trim()}”. Try a different spelling.</p>}
        <ul id="search-list" role="listbox">
          {searching ? list(results, 0) : <>
            {favs.length > 0 && <li className="sgroup"><Star size={13} strokeWidth={1.8} /> Favorites</li>}
            {list(favs, 0)}
            {recentOnly.length > 0 && <li className="sgroup"><History size={13} strokeWidth={1.8} /> Recent <button type="button" className="link" onClick={onClearRecent}>Clear</button></li>}
            {list(recentOnly, favs.length)}
          </>}
        </ul>
        {!searching && !flat.length && <p className="muted center">Type at least two letters to search cities worldwide.<br />Cities you favorite or visit will appear here.</p>}
      </div>
    </Modal>
  );
}
