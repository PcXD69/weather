import { Trash2 } from 'lucide-react';
import type { Place, Settings } from '../types';
import { Modal } from './Modal';
import { Segmented, Switch } from './ui';

export function SettingsModal({ open, onClose, settings, onChange, favs, onRemoveFav, onPick, onReset }: {
  open: boolean; onClose: () => void; settings: Settings; onChange: (s: Settings) => void;
  favs: Place[]; onRemoveFav: (p: Place) => void; onPick: (p: Place) => void; onReset: () => void;
}) {
  const set = <K extends keyof Settings>(k: K, v: Settings[K]) => onChange({ ...settings, [k]: v });
  return (
    <Modal open={open} onClose={onClose} title="Settings" wide>
      <div className="set-grid">
        <div className="set-row"><span>Temperature</span><Segmented label="Temperature" value={settings.temp} onChange={v => set('temp', v)} options={[{ value: 'c', label: '°C' }, { value: 'f', label: '°F' }]} /></div>
        <div className="set-row"><span>Wind speed</span><Segmented label="Wind speed" value={settings.wind} onChange={v => set('wind', v)} options={[{ value: 'kmh', label: 'km/h' }, { value: 'mph', label: 'mph' }, { value: 'ms', label: 'm/s' }, { value: 'kn', label: 'kn' }]} /></div>
        <div className="set-row"><span>Pressure</span><Segmented label="Pressure" value={settings.pressure} onChange={v => set('pressure', v)} options={[{ value: 'hpa', label: 'hPa' }, { value: 'inhg', label: 'inHg' }]} /></div>
        <div className="set-row"><span>Time format</span><Segmented label="Time format" value={settings.h24 ? '24' : '12'} onChange={v => set('h24', v === '24')} options={[{ value: '12', label: '12 h' }, { value: '24', label: '24 h' }]} /></div>
        <div className="set-row"><span>Auto-refresh</span>
          <Segmented label="Auto-refresh" value={String(settings.refresh)} onChange={v => set('refresh', Number(v))} options={[{ value: '5', label: '5 m' }, { value: '10', label: '10 m' }, { value: '30', label: '30 m' }, { value: '0', label: 'Off' }]} /></div>
        <div className="set-row"><span>Visual effects</span><Segmented label="Visual effects" value={settings.effects} onChange={v => set('effects', v)} options={[{ value: 'full', label: 'Full' }, { value: 'low', label: 'Light' }]} /></div>
        <div className="set-row"><span>Follow local daylight<small>Switch day/night theme to match the selected city</small></span><Switch label="Follow local daylight" checked={settings.autoTheme} onChange={v => set('autoTheme', v)} /></div>
      </div>
      <h3 className="set-h">Favorite cities</h3>
      {favs.length === 0 ? <p className="muted">No favorites yet. Tap the heart on any city.</p> : (
        <ul className="favlist">{favs.map(p => (
          <li key={p.id}><button type="button" onClick={() => onPick(p)}><b>{p.name}</b><small>{[p.admin1, p.country].filter(Boolean).join(', ')}</small></button>
            <button type="button" className="iconbtn" aria-label={`Remove ${p.name}`} onClick={() => onRemoveFav(p)}><Trash2 size={16} strokeWidth={1.8} /></button></li>
        ))}</ul>
      )}
      <button type="button" className="btn danger" onClick={onReset}>Reset all saved data</button>
      <p className="muted small">Weather data by <a href="https://open-meteo.com/" target="_blank" rel="noreferrer">Open-Meteo.com</a> (CC BY 4.0).</p>
    </Modal>
  );
}
