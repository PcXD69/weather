import { Cloud, CloudDrizzle, CloudFog, CloudLightning, CloudMoon, CloudRain, CloudSnow, CloudSun, Moon, Sun } from 'lucide-react';
import type { IconKey } from '../types';

export function WeatherIcon({ icon, isDay, size = 28, stroke = 1.6, className = '' }: { icon: IconKey; isDay: boolean; size?: number; stroke?: number; className?: string }) {
  const p = { size, strokeWidth: stroke, 'aria-hidden': true };
  const I =
    icon === 'clear' ? (isDay ? Sun : Moon) :
    icon === 'partly' ? (isDay ? CloudSun : CloudMoon) :
    icon === 'cloudy' ? Cloud : icon === 'fog' ? CloudFog : icon === 'drizzle' ? CloudDrizzle :
    icon === 'rain' ? CloudRain : icon === 'snow' ? CloudSnow : CloudLightning;
  return <span className={`wi wi-${icon} ${isDay ? 'day' : 'night'} ${className}`}><I {...p} /></span>;
}
