import { createContext, useContext } from 'react';
import type { Settings } from '../types';

export const DEFAULT_SETTINGS: Settings = { temp: 'c', wind: 'kmh', pressure: 'hpa', h24: false, refresh: 10, autoTheme: false, effects: 'full' };
export const SettingsContext = createContext<Settings>(DEFAULT_SETTINGS);
export const useSettings = () => useContext(SettingsContext);
