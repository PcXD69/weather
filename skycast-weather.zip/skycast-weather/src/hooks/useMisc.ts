import { useEffect, useRef, useState } from 'react';

export function useLocalStorage<T>(key: string, init: T) {
  const [value, setValue] = useState<T>(() => {
    try {
      const raw = localStorage.getItem(key);
      if (raw !== null) {
        const parsed = JSON.parse(raw);
        return init && typeof init === 'object' && !Array.isArray(init) && parsed && typeof parsed === 'object'
          ? ({ ...init, ...parsed } as T) : (parsed as T);
      }
    } catch { /* ignore corrupt data */ }
    return init;
  });
  useEffect(() => {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* storage unavailable */ }
  }, [key, value]);
  return [value, setValue] as const;
}

export function useReducedMotion() {
  const q = '(prefers-reduced-motion: reduce)';
  const [r, setR] = useState(() => window.matchMedia(q).matches);
  useEffect(() => {
    const m = window.matchMedia(q);
    const on = () => setR(m.matches);
    m.addEventListener('change', on);
    return () => m.removeEventListener('change', on);
  }, []);
  return r;
}

export function useNow(ms = 20000) {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), ms);
    return () => window.clearInterval(id);
  }, [ms]);
  return now;
}

/** Smoothly tweens a number (used for the big temperature). */
export function useAnimatedNumber(target: number, duration = 900) {
  const reduced = useReducedMotion();
  const from = useRef(target - 12);
  const [v, setV] = useState(from.current);
  useEffect(() => {
    if (reduced) { from.current = target; setV(target); return; }
    const start = from.current, t0 = performance.now();
    let raf = 0;
    const step = (now: number) => {
      const p = Math.min(1, (now - t0) / duration);
      const val = start + (target - start) * (1 - Math.pow(1 - p, 3));
      from.current = val; setV(val);
      if (p < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [target, duration, reduced]);
  return v;
}
