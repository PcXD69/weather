import { useCallback, useEffect, useRef, useState } from 'react';
import type { Place, Weather } from '../types';
import { fetchWeather, isFresh, readCache } from '../lib/api';

interface State { data: Weather | null; loading: boolean; error: string | null; stale: boolean }

export function useWeather(place: Place | null, refreshMin: number) {
  const [s, setS] = useState<State>({ data: null, loading: false, error: null, stale: false });
  const ctl = useRef<AbortController | null>(null);
  const last = useRef(0);

  const load = useCallback(async (force = false) => {
    if (!place) return;
    const cached = readCache(place);
    if (!force && isFresh(cached)) { setS({ data: cached, loading: false, error: null, stale: false }); last.current = cached!.fetchedAt; return; }
    ctl.current?.abort();
    const c = new AbortController();
    ctl.current = c;
    setS(p => ({ data: p.data ?? cached, loading: true, error: null, stale: !!(p.data ?? cached) }));
    try {
      const data = await fetchWeather(place, c.signal);
      last.current = data.fetchedAt;
      setS({ data, loading: false, error: null, stale: false });
    } catch (e: any) {
      if (e?.name === 'AbortError') return;
      setS(p => ({ ...p, loading: false, stale: !!p.data, error: navigator.onLine ? 'We could not reach the weather service. Please try again.' : 'You appear to be offline.' }));
    }
  }, [place]);

  // New place → show cached data immediately, then refresh if needed.
  useEffect(() => {
    const cached = place ? readCache(place) : null;
    setS({ data: cached, loading: !!place && !cached, error: null, stale: !!cached });
    void load();
    return () => ctl.current?.abort();
  }, [place, load]);

  // Automatic updates + refresh when the tab becomes visible again or the network returns.
  useEffect(() => {
    if (!place) return;
    const ms = refreshMin * 60000;
    const id = refreshMin > 0 ? window.setInterval(() => void load(true), ms) : 0;
    const vis = () => { if (document.visibilityState === 'visible' && refreshMin > 0 && Date.now() - last.current > ms) void load(true); };
    const online = () => void load(true);
    document.addEventListener('visibilitychange', vis);
    window.addEventListener('online', online);
    return () => { if (id) window.clearInterval(id); document.removeEventListener('visibilitychange', vis); window.removeEventListener('online', online); };
  }, [place, refreshMin, load]);

  return { ...s, refresh: () => load(true) };
}
