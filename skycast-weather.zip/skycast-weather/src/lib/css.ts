import type { CSSProperties } from 'react';

/** Typed helper for CSS custom properties: style={cssVars({ '--i': 2 })} */
export const cssVars = (v: Record<string, string | number>) => v as CSSProperties;
