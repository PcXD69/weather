import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

/**
 * GitHub Pages base path.
 *
 * './' (relative) works for ANY repository name, for user sites
 * (username.github.io) and for custom domains, so you do not have to edit anything.
 *
 * If you prefer an absolute base for a project site, replace './' with
 * '/YOUR-REPOSITORY-NAME/' (keep both slashes), or set VITE_BASE in the workflow.
 */
export default defineConfig({
  base: process.env.VITE_BASE || './',
  plugins: [react()],
  build: { target: 'es2020', sourcemap: false },
});
